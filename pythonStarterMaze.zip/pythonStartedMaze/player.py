class Player:
    def __init__(self, intitalRow, initialColumn):
        self.rowPosition = intitalRow
        self.columnPosition = initialColumn

    # TODO
    # def moveUp(self):

    # TODO
    # def moveDown(self):

    # TODO
    # def moveLeft(self):

    # TODO
    # def moveRight(self):
